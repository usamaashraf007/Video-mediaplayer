package com.example.vplayer007;

import android.content.Context;
import android.graphics.Point;
import android.media.AudioManager;
import android.media.MediaPlayer;

import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;



public class videoPlayerActivity extends AppCompatActivity implements GestureDetector.OnGestureListener {


    private static final String TAG = "Swipe Position";
    private float x1, x2, y1, y2;
    private static int MIN_DISTANCE = 150;
    private GestureDetector gestureDetector;

    VideoView videoView;
    int position = -1;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);

        videoView = (VideoView) findViewById(R.id.myPlayer);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        position = getIntent().getIntExtra("position", -1);
        getSupportActionBar().hide();
        playerVideo();


        //initializtion gesture detector
         this.gestureDetector = new GestureDetector(videoPlayerActivity.this,this);
    }









   //For sensors working
    @Override
    public boolean onTouchEvent(MotionEvent event) {

        gestureDetector.onTouchEvent(event);
        switch (event.getAction()){
            //starting to swipe time gesture
            case MotionEvent.ACTION_DOWN:
                x1 = event.getX();
                y1 = event.getY();
                break;
            //ending swipe gesture
            case MotionEvent.ACTION_UP:
                x2 = event.getX();
                y2 = event.getY();;

                //getting value for horizontal swipe
                float valueX = x2-x1;
                //getting value for vertical swipe
                float valueY = y2-y1;


                if (Math.abs(valueX) > MIN_DISTANCE)
                {
                    //detect left to right swipe
                    if (x2>x1)
                    {


                        Toast.makeText(this, "Right is swipe", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "Right swipe");
                    }
                    else
                    {
                        //detect from right to left swipe
                        Toast.makeText(this, "left swiped", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "Left swipe");
                    }
                }
                else if (Math.abs(valueY)>MIN_DISTANCE)
                {
                    //detect top to bottom swipe
                    if (y2>y1)
                    {
                        Toast.makeText(this, "Bottom is swiped", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "Bottom is swipe");
                    }
                    else
                    {
                        //detetc bottom to top
                        Toast.makeText(this, "Top swipe", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "Top swipe");
                    }
                }
        }
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }

    private void playerVideo() {


        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(videoView);

        videoView.setMediaController(mediaController);
        videoView.setVideoPath(String.valueOf(MainActivity.fileArrayList.get(position)));
        videoView.requestFocus();

        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {

            @Override
            public void onPrepared(MediaPlayer mp) {

                videoView.start();


            }
        });

        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                videoView.setVideoPath(String.valueOf(MainActivity.fileArrayList.get(position = position + 1)));
                videoView.start();
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        videoView.stopPlayback();
    }


}